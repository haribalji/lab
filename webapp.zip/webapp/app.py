from flask import Flask, render_template, request
import smtplib
from email.message import EmailMessage

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/webapp', methods=['POST'])
def send_email():
    # Email details
    msg = EmailMessage()
    msg['Subject'] = 'Hello from Flask App'
    msg['From'] = 'kajamydeenhalik@gmail.com'
    msg['To'] = 'nayaganavis2004@gmail.com'
    msg.set_content('This email was sent by clicking a button!')

    # Send via Gmail SMTP
    with smtplib.SMTP('smtp.gmail.com', 587) as smtp:
        smtp.starttls()
        smtp.login('kajamydeenhalik@gmail.com', 'aufgjvzqbqmspfnd')  # use your App Password
        smtp.send_message(msg)

    return "Email sent successfully!"

if __name__ == '__main__':
    app.run(debug=True)
